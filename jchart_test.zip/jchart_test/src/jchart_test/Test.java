package jchart_test;

import java.awt.Color;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JFrame;

import info.monitorenter.gui.chart.Chart2D;
import info.monitorenter.gui.chart.ITrace2D;
import info.monitorenter.gui.chart.traces.Trace2DSimple;

public class Test {

	private Test(){
		super();
	}
	
	public static void main(String[] args) {
	    Chart2D chart = new Chart2D();
	    
	    ArrayList<Color> colors = new ArrayList<Color>();
	    
	    colors.add(Color.black);
	    colors.add(Color.blue);
	    colors.add(Color.cyan);
	    colors.add(Color.green);
	    colors.add(Color.red);
	    colors.add(Color.orange);
	    colors.add(Color.pink);
	    colors.add(Color.yellow);
	    colors.add(Color.lightGray);
	    colors.add(Color.magenta);
 
	    for (int j = 1; j < 11; j++){
		    ITrace2D trace = new Trace2DSimple(); 
		    
		    trace.setColor(colors.get(j-1));
		    
		    chart.addTrace(trace);    
		    Random random = new Random();
		    for(int i=10000;i>=0;i--){
		      trace.addPoint(i,random.nextDouble()*1000.0+j*1000+i);
		    }
	    }

	    
	    // swing to display chart
	    JFrame frame = new JFrame("MinimalStaticChart");
	    frame.getContentPane().add(chart);
	    frame.setSize(400,300); 
	    frame.addWindowListener(
	        new WindowAdapter(){
	          public void windowClosing(WindowEvent e){
	              System.exit(0);
	          }
	        }
	      );
	    frame.setVisible(true);
	  }
}
